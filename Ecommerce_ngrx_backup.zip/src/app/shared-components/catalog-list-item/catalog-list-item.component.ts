import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-catalog-list-item',
  templateUrl: './catalog-list-item.component.html',
  styleUrls: ['./catalog-list-item.component.scss']
})
export class CatalogListItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
