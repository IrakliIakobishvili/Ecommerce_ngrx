import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-category-header',
  templateUrl: './category-header.component.html',
  styleUrls: ['./category-header.component.scss']
})
export class CategoryHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
