import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-category-filter',
  templateUrl: './category-filter.component.html',
  styleUrls: ['./category-filter.component.scss']
})
export class CategoryFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
