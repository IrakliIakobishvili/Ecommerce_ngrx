import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-advanced-filter',
  templateUrl: './advanced-filter.component.html',
  styleUrls: ['./advanced-filter.component.scss']
})
export class AdvancedFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
