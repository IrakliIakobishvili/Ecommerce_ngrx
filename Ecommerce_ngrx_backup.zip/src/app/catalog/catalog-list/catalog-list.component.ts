import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-catalog-list',
  templateUrl: './catalog-list.component.html',
  styleUrls: ['./catalog-list.component.scss']
})
export class CatalogListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
