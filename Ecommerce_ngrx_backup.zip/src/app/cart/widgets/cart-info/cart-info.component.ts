import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-cart-info',
  templateUrl: './cart-info.component.html',
  styleUrls: ['./cart-info.component.scss']
})
export class CartInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
