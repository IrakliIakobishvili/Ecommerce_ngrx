import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-cart-table',
  templateUrl: './cart-table.component.html',
  styleUrls: ['./cart-table.component.scss']
})
export class CartTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
