import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import {DashboardRoutingModule} from './dashboard.routing.module';
import { AlertsComponent } from './widgets/alerts/alerts.component';
import { BalanceComponent } from './widgets/balance/balance.component';
import { ChartComponent } from './widgets/chart/chart.component';
import { NewsAndUpdatesComponent } from './widgets/news-and-updates/news-and-updates.component';
import { SupportComponent } from './widgets/support/support.component';

@NgModule({
declarations: [DashboardComponent, AlertsComponent, BalanceComponent, ChartComponent, NewsAndUpdatesComponent, SupportComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule
  ]
})
export class DashboardModule { }
