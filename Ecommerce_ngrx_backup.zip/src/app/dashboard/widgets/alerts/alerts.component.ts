import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})
export class AlertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
