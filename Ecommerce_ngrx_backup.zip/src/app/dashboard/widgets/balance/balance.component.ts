import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.scss']
})
export class BalanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
