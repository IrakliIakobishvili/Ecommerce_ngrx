import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
