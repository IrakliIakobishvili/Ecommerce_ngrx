import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'drop-news-and-updates',
  templateUrl: './news-and-updates.component.html',
  styleUrls: ['./news-and-updates.component.scss']
})
export class NewsAndUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
